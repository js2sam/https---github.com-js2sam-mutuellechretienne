
 
<?php $__env->startSection('title', 'Nos offres'); ?>

<?php $__env->startSection('state_nosoffres', 'class=borderBottom'); ?>

<?php $__env->startSection('state_nosoffres_active', 'active'); ?>

<?php $__env->startSection('sidebar'); ?>
    @parent
 
    <p>This is appended to the master sidebar.</p>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('content'); ?>
    <p>This is my body content.</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\sites\wwwroot\mutuellechretienne\resources\views/nosoffres.blade.php ENDPATH**/ ?>