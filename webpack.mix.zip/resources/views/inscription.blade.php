@extends('template')

@section('title', 'Accueil')

@section('content')

@endsection